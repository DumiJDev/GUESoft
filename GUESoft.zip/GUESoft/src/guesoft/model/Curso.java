package guesoft.model;

public enum Curso {
    Informatica,
    Electricidade,
    Mecanica
}
